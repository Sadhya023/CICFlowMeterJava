# Network Logger (Pcap4J + Webhook)

## Requirements
- Java 8+ (JDK)
- On Windows: Npcap installed with WinPcap compatibility
- Internet access for Gradle to download dependencies on first run

## How to use

1. Open a terminal in this folder.
2. On first run, let Gradle download dependencies:

   - On Windows:
     gradlew.bat build

   - On Linux/macOS:
     ./gradlew build

3. Put your webhook URL in `NetworkLogger.java`:

   private static final String WEBHOOK_URL = "https://your-webhook-url-here";

   Optionally change `INTERFACE_NAME` or pass it as argument.

4. Build and run:

   - Windows:
     gradlew.bat run --args="Wi-Fi"

   - Linux:
     ./gradlew run --args="eth0"

Replace the interface string with your actual interface name.

## Note
This project uses Gradle to fetch all required JARs automatically from Maven Central. You do NOT need to download Pcap4J manually.
