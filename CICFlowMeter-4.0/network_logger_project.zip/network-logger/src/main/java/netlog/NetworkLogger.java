package netlog;

import org.pcap4j.core.*;
import org.pcap4j.packet.Packet;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.TimeoutException;

public class NetworkLogger {

    // === CONFIG: EDIT THESE ===
    private static final String INTERFACE_NAME = "CHANGE_ME"; // e.g. "Wi-Fi" on Windows or "eth0" / "wlan0" on Linux
    private static final String WEBHOOK_URL = "https://example.com/your-webhook"; // <-- put your webhook.site URL here
    private static final int SNAPLEN = 65536; // bytes
    private static final int READ_TIMEOUT_MS = 50; // ms
    private static final int MAX_PACKETS = -1; // -1 = infinite

    public static void main(String[] args) {
        String ifaceName = INTERFACE_NAME;

        if (args.length >= 1) {
            ifaceName = args[0];
        }

        System.out.println("Using interface: " + ifaceName);
        System.out.println("Webhook: " + WEBHOOK_URL);

        try {
            PcapNetworkInterface nif = findInterfaceByName(ifaceName);
            if (nif == null) {
                System.err.println("Could not find interface: " + ifaceName);
                listInterfaces();
                return;
            }

            System.out.println("Capturing on: " + nif.getName() + " (" + nif.getDescription() + ")");

            PcapHandle handle = nif.openLive(
                    SNAPLEN,
                    PcapNetworkInterface.PromiscuousMode.PROMISCUOUS,
                    READ_TIMEOUT_MS
            );

            PacketListener listener = packet -> {
                try {
                    String summary = packet.toString();
                    String hex = bytesToHex(packet.getRawData());

                    String payloadJson = "{"
                            + "\"summary\":" + jsonString(summary) + ","
                            + "\"hex\":" + jsonString(hex) + ","
                            + "\"length\":" + packet.length()
                            + "}";

                    sendToWebhook(WEBHOOK_URL, payloadJson);
                    System.out.println("Packet sent to webhook. Size=" + packet.length());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            };

            int count = MAX_PACKETS;
            try {
                handle.loop(count, listener);
            } catch (InterruptedException e) {
                System.out.println("Capture interrupted.");
            } catch (PcapNativeException | NotOpenException e) {
                e.printStackTrace();
            } finally {
                if (handle != null && handle.isOpen()) {
                    handle.close();
                }
            }

        } catch (PcapNativeException e) {
            e.printStackTrace();
        }
    }

    private static PcapNetworkInterface findInterfaceByName(String name) throws PcapNativeException {
        List<PcapNetworkInterface> nifs = Pcaps.findAllDevs();
        if (nifs == null) {
            System.err.println("No interfaces found. Is Npcap / WinPcap installed?");
            return null;
        }

        for (PcapNetworkInterface nif : nifs) {
            if (nif.getName().equalsIgnoreCase(name) ||
                (nif.getDescription() != null && nif.getDescription().equalsIgnoreCase(name))) {
                return nif;
            }
            // also try matching the friendly name from NetworkInterface
            try {
                NetworkInterface ni = nif.getNetworkInterface();
                if (ni != null && ni.getDisplayName() != null &&
                    ni.getDisplayName().equalsIgnoreCase(name)) {
                    return nif;
                }
            } catch (Exception ignored) {}
        }

        System.out.println("Available interfaces:");
        for (PcapNetworkInterface nif : nifs) {
            System.out.println(" - " + nif.getName() + " : " + nif.getDescription());
        }
        return null;
    }

    private static void listInterfaces() throws PcapNativeException {
        List<PcapNetworkInterface> nifs = Pcaps.findAllDevs();
        if (nifs == null) {
            System.err.println("No interfaces found. Is Npcap / WinPcap installed?");
            return;
        }
        System.out.println("Available interfaces:");
        for (PcapNetworkInterface nif : nifs) {
            System.out.println(" - " + nif.getName() + " : " + nif.getDescription());
        }
    }

    private static String jsonString(String s) {
        if (s == null) return "null";
        String escaped = s
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
        return "\"" + escaped + "\"";
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b: bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private static void sendToWebhook(String url, String jsonBody) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(url);
            conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json");

            byte[] out = jsonBody.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(out.length);
            conn.connect();
            conn.getOutputStream().write(out);

            int code = conn.getResponseCode();
            System.out.println("Webhook response code: " + code);

            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(
                            code >= 400 ? conn.getErrorStream() : conn.getInputStream(),
                            StandardCharsets.UTF_8))) {
                String line;
                while (br != null && (line = br.readLine()) != null) {
                    // Optionally print response
                    // System.out.println(line);
                    break; // just read first line
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to send to webhook: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
